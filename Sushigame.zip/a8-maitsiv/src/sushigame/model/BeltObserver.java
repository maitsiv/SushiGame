package sushigame.model;

public interface BeltObserver {
	public void handleBeltEvent(BeltEvent e);
}
