package sushigame.model;

import comp401sushi.Plate;

public interface Customer {

	boolean consumesPlate(Plate p);
}
