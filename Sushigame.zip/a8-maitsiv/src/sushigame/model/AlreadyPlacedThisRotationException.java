package sushigame.model;

public class AlreadyPlacedThisRotationException extends Exception {

}
