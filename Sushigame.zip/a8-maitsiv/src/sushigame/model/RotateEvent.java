package sushigame.model;

public class RotateEvent extends BeltEvent {
	public RotateEvent() {
		super(BeltEvent.EventType.ROTATE);
	}
}
