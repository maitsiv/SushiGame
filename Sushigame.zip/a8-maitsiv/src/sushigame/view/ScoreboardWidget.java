package sushigame.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Comparator;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import sushigame.model.Belt;
import sushigame.model.BeltEvent;
import sushigame.model.BeltObserver;
import sushigame.model.Chef;
import sushigame.model.SushiGameModel;

public class ScoreboardWidget extends JPanel implements BeltObserver, ActionListener {

	private SushiGameModel game_model;
	private JLabel display;
	private Chef[] chefs;
	
	public ScoreboardWidget(SushiGameModel gm) {
		game_model = gm;
		game_model.getBelt().registerBeltObserver(this);
		
		display = new JLabel();
		display.setVerticalAlignment(SwingConstants.TOP);
		setLayout(new BorderLayout());
		add(display, BorderLayout.CENTER);
		display.setText(makeScoreboardHTML());
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		
		
		JLabel scoreLabel = new JLabel("Click to sort by: ");
		add(scoreLabel);
				//JPanel sortPanel = new JPanel();
				//add(sortPanel);
				JButton sortBySpoiled = new JButton("Sort by spoiled food!");
				sortBySpoiled.setActionCommand("spoiled");
				sortBySpoiled.addActionListener(this);
				add(sortBySpoiled);
				
				//FOOD CONSUMED SORT
				//JPanel consumedPanel = new JPanel();
				//add(consumedPanel);
				JButton sortByConsumed = new JButton("Sort by consumed food!");
				sortByConsumed.setActionCommand("consumed");
				sortByConsumed.addActionListener(this);
				add(sortByConsumed);
				
				
				//BALANCE SORT
				//JPanel balancePanel = new JPanel();
				//add(balancePanel);
				JButton sortByBalance = new JButton("Sort by balance!");
				sortByBalance.setActionCommand("balance");
				sortByBalance.addActionListener(this);
				add(sortByBalance);
				
				
	}

	private String makeScoreboardHTML() {
		String sb_html = "<html>";
		sb_html += "<h1>Scoreboard</h1>";

		// Create an array of all chefs and sort by balance.
		Chef[] opponent_chefs= game_model.getOpponentChefs();
		chefs = new Chef[opponent_chefs.length+1];
		chefs[0] = game_model.getPlayerChef();
		for (int i=1; i<chefs.length; i++) {
			chefs[i] = opponent_chefs[i-1];
		}
		
		
		
		
		
		
		
		
		
		Arrays.sort(chefs, new HighToLowBalanceComparator());
		
		for (Chef c : chefs) {
			sb_html += c.getName() + " ($" + Math.round(c.getBalance()*100.0)/100.0 + ") <br>";
		}
		return sb_html;
		
		
		
		
		
	}

	public void refresh() {
		display.setText(makeScoreboardHTML());		
	}
	
	@Override
	public void handleBeltEvent(BeltEvent e) {
		if (e.getType() == BeltEvent.EventType.ROTATE) {
			refresh();
		}		
	}
	
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "consumed" : 
			Arrays.sort(chefs, new HighToLowConsumedComparator());
			String sb_html = "<html>";
			sb_html += "<h1>Scoreboard</h1>";

			for (Chef c : chefs) {
				sb_html += c.getName() + " ( " + Math.round(c.getConsumed()*100.0)/100.0 + " oz) <br>";
			}
			display.setText(sb_html);
			break;
		case "spoiled" :
			Arrays.sort(chefs, new HighToLowSpoiledComparator());
			String sb_html1 = "<html>";
			sb_html1 += "<h1>Scoreboard</h1>";

			for (Chef c : chefs) {
				sb_html1 += c.getName() + " ( " + Math.round(c.getSpoiled()*100.0)/100.0 + " oz) <br>";
			}
			display.setText(sb_html1);
			break;
		case "balance" : 
			Arrays.sort(chefs, new HighToLowBalanceComparator());
			String sb_html2 = "<html>";
			sb_html2 += "<h1>Scoreboard</h1>";

			for (Chef c : chefs) {
				sb_html2 += c.getName() + " ( $" + Math.round(c.getBalance()*100.0)/100.0 + ") <br>";
			}
			display.setText(sb_html2);
			
			break;
		}
		
		
		
		
		
	}

}
