package sushigame.view;

import java.awt.Button;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import comp401sushi.Plate;
//import comp401sushi.Plate.Color;
import comp401sushi.Roll;
import comp401sushi.Sashimi;
import sushigame.model.Belt;
import sushigame.model.BeltEvent;
import sushigame.model.BeltObserver;

public class PlateView extends JPanel implements ActionListener{
	
	private Belt b;
	private Plate p;
	private int position;
	private JButton infoButton;
	private JFrame frame;
	private JLabel plabel;
	
		
	
	public PlateView(Plate p, Belt b, int position) {
		this.b = b;
		this.p = p;
		this.position = position;
		/*plabel = new JLabel("");
		plabel.setMinimumSize(new Dimension(300, 20));
		plabel.setPreferredSize(new Dimension(300, 20));
		plabel.setOpaque(true);
		plabel.setBackground(Color.GRAY);
		
		add(plabel);*/
		

		infoButton = new JButton("click for plate info");
		infoButton.setActionCommand("info");
		infoButton.addActionListener(this);
		this.add(infoButton);
		
		//frame = new JFrame();
				
		
	}
	
	
	
	public void updatePlate(Plate c, Belt b, int position) {
		
		this.p = c;
		this.b = b;
		this.position = position;
		//return new PlateView(c, b, position);
		
		
		//return newPlateView;
		
	}
	
	
	
	
	

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if (b.getPlateAtPosition(position) != null) {
			String plateChef = "";
			String plateAge = "";		
			String plateColor = "Color: " + b.getPlateAtPosition(position).getColor().name();  
			String plateType = "Type: " + b.getPlateAtPosition(position).getContents().getName();
			String plateIngs = "";
			String ingAndAmt = "";
			String plateName = "";
			
			if (b.getPlateAtPosition(position).getContents() instanceof Roll) {
			
			//if (!b.getPlateAtPosition(position).getContents().getName().contains("sashimi") || 
			//!b.getPlateAtPosition(position).getContents().getName().contains("")) {
				
				for (int j = 0 ; j < b.getPlateAtPosition(position).getContents().getIngredients().length; j++) {
					System.out.println(b.getPlateAtPosition(position).getContents().getIngredients()[j]);
					ingAndAmt = ingAndAmt +  b.getPlateAtPosition(position).getContents().getIngredients()[j].getAmount() + " oz of " +
							b.getPlateAtPosition(position).getContents().getIngredients()[j].getName() + " \n ";
				}
				plateType =  "Type: " + b.getPlateAtPosition(position).getContents().getName() +
						" Roll with: " +  "\n" + ingAndAmt;
				plateChef = "Chef: " + b.getPlateAtPosition(position).getChef().getName();
				plateAge = "Age: " + b.getAgeOfPlateAtPosition(position);
				
			} else {
				plateChef = "Chef: " + b.getPlateAtPosition(position).getChef().getName();
				plateAge = "Age: " + b.getAgeOfPlateAtPosition(position);

			}
			
			JOptionPane.showMessageDialog(frame, plateColor + "\n"+ plateType + " \n" + plateChef + " \n" + plateAge);
					
		}
		
		
	}

}
