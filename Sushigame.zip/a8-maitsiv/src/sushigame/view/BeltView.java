package sushigame.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import comp401sushi.Plate;
import sushigame.model.Belt;
import sushigame.model.BeltEvent;
import sushigame.model.BeltObserver;

public class BeltView extends JPanel implements BeltObserver {

	private Belt belt;
	private JLabel[] belt_labels;
	private PlateView plateView;
	private PlateView[] plates;

	public BeltView(Belt b) {
		this.belt = b;
		belt.registerBeltObserver(this);
		setLayout(new GridLayout(belt.getSize(), 1));
		setPreferredSize(new Dimension(300, 300));
		belt_labels = new JLabel[belt.getSize()];
		plates = new PlateView[belt.getSize()];
		for (int i = 0; i < belt.getSize(); i++) {			

			
			plates[i] = new PlateView(belt.getPlateAtPosition(i), belt, i);
			add(plates[i]);
		}
		
		
		refresh();
	}

	@Override
	public void handleBeltEvent(BeltEvent e) {	
		refresh();
	}

	private void refresh() {
		JLabel plabel = new JLabel();
		String plabelWords = "";
		for (int i=0; i<belt.getSize(); i++) {
			Plate p = belt.getPlateAtPosition(i);
			PlateView newPlate = new PlateView(p, belt, i);
			newPlate.updatePlate(p, belt, i);
			
			//plates[i].updatePlate(p, belt, i);			 

			if (p == null) {
				//belt.clearPlateAtPosition(i);
				plates[i].setBackground(Color.GRAY);
				
			} else {
				//plates[i] = plates[i].updatePlate(p, belt, i);
				//plates[i].updatePlate(p, belt);	
				switch (p.getColor()) {
				case RED:
					plates[i].setBackground(Color.RED); 
					plabelWords = "Red Plate";			
					break;
				case GREEN:
					plates[i].setBackground(Color.GREEN); 
					plabelWords = "Green Plate";
					break;
				case BLUE:
					plates[i].setBackground(Color.BLUE); 
					plabelWords = "Blue Plate";
					break;
				case GOLD:
					plates[i].setBackground(Color.YELLOW); 
					plabelWords = "Gold Plate";
					break;
				}				

			}
			
			
		}
		plabel.setText(plabelWords);
		
		
		
		
	}
}
