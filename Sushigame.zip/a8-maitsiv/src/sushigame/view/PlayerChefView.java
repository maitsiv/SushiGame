package sushigame.view;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.Border;

import comp401sushi.AvocadoPortion;
import comp401sushi.CrabPortion;
import comp401sushi.EelPortion;
import comp401sushi.IngredientPortion;
import comp401sushi.Nigiri;
import comp401sushi.Nigiri.NigiriType;
import comp401sushi.Plate;
import comp401sushi.RedPlate;
import comp401sushi.RicePortion;
import comp401sushi.Roll;
import comp401sushi.Sashimi;
import comp401sushi.Sashimi.SashimiType;
import comp401sushi.SeaweedPortion;
import comp401sushi.ShrimpPortion;
import comp401sushi.Sushi;
import comp401sushi.TunaPortion;
import comp401sushi.YellowtailPortion;

public class PlayerChefView extends JPanel implements ActionListener {

	private List<ChefViewListener> listeners;
	private Sushi kmp_roll;
	private Sushi crab_sashimi;
	private Sushi eel_nigiri;
	private int belt_size;
	private String colorsBox;
	private String ingredientsBox;
	private String sushiBox;
	private int platePositionBox;
	//private String[] ingredientSliders;
	private JSlider slider;
	private double[] ingredientRollPortions;
	private JSlider[] ingSliders;
	private JSlider goldPlatePriceSlider;
	private double goldPrice;
	private JPanel goldPlatePrice;
	private Sushi plateOfSushi;
	private String rollName;
	private JComboBox colors;
	private JComboBox sushi;
	private JComboBox ingredients;
	private JComboBox platePositionOps;
	private JTextField nameOfRoll;
	
	//private Ingredient[] rawIngredients;
	private String[] ingredientSliders = {"Avocado", "Tuna", "Eel", "Crab", "Yellowtail", "Shrimp", "Rice", "Seaweed"};
	
	
	
	
	
	public PlayerChefView(int belt_size) {
		this.belt_size = belt_size;
		listeners = new ArrayList<ChefViewListener>();

		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.setMinimumSize(new Dimension(1000, 800));		
		JFrame boxFrame = new JFrame();
		ingredientRollPortions = new double[ingredientSliders.length];
		ingSliders = new JSlider[ingredientSliders.length];
		
		

		//PLATE COLOR
		JPanel colorPanel = new JPanel();
		JLabel colorPanelTitle = new JLabel("Choose Plate Color");
		colorPanel.add(colorPanelTitle);	
		//Border border2 = BorderFactory.createTitledBorder(colorPanelTitle);
		//colorPanel.setBorder(border2);
		add(colorPanel);
		colors = new JComboBox();
		colors.addItem("");
		colors.addItem("green");
		colors.addItem("red");
		colors.addItem("blue");
		colors.addItem("gold");	
		colorPanel.add(colors);
		colors.addActionListener(this);
		colorsBox = (String) colors.getSelectedItem();
		colors.setActionCommand("color");
		

		//PRICE FOR GOLD PLATE
		goldPlatePrice = new JPanel();
		JLabel goldPlatePriceTitle =  new JLabel("Choose Gold Plate Price: ");
		goldPlatePrice.add(goldPlatePriceTitle);
		//Border border6 = BorderFactory.createTitledBorder(goldPlatePriceTitle);
		//platePosition.setBorder(border6);
		add(goldPlatePrice);
		goldPlatePriceSlider = new JSlider(JSlider.HORIZONTAL, 5, 10, 5);
		goldPlatePriceSlider.setMajorTickSpacing(2);
		goldPlatePriceSlider.setMinorTickSpacing(1);
		goldPlatePriceSlider.setPaintTicks(true);
		Hashtable<Integer, JLabel> position1 = new Hashtable<Integer, JLabel>();
        position1.put(0, new JLabel("$0"));
        position1.put(2, new JLabel("$2"));
        position1.put(4, new JLabel("$4"));
        position1.put(6, new JLabel("$6"));
        position1.put(8, new JLabel("$8"));
        position1.put(10, new JLabel("$10"));
        goldPlatePriceSlider.setLabelTable(position1);
		goldPlatePriceSlider.setPaintLabels(true);		
		goldPlatePrice.add(goldPlatePriceSlider);
		goldPrice = goldPlatePriceSlider.getValue()*100/100.0;
		//goldPlatePrice.setVisible(true);	
		goldPlatePriceSlider.setVisible(false);
		
		

		//SUSHI TYPE
		JPanel typeOfSushi = new JPanel();
		JLabel title = new JLabel("Choose Sushi Type");
		typeOfSushi.add(title);
		//Border border = BorderFactory.createTitledBorder(title);
		//typeOfSushi.setBorder(border);
		add(typeOfSushi);		
		sushi = new JComboBox();
		sushi.addItem("");
		sushi.addItem("nigiri");
		sushi.addItem("sashimi");
		sushi.addItem("roll");		
		typeOfSushi.add(sushi);
		sushi.addActionListener(this);
		sushi.setActionCommand("sushi type");
		sushiBox = (String) sushi.getSelectedItem();	
		
		//INGREDIENT SINGLE
		JPanel ingPanel = new JPanel();
		JLabel ingPanelTitle = new JLabel("Choose Ingredient for Sashimi/Nigiri");
		ingPanel.add(ingPanelTitle);
		//Border border3 = BorderFactory.createTitledBorder(ingPanelTitle);
		//ingPanel.setBorder(border3);
		add(ingPanel);
		ingredients = new JComboBox();
		ingredients.addItem("");
		ingredients.addItem("eel");
		ingredients.addItem("tuna");
		ingredients.addItem("shrimp");
		ingredients.addItem("yellowtail");
		ingredients.addItem("crab");
		ingPanel.add(ingredients);
		ingredients.addActionListener(this);
		ingredients.setActionCommand("single ing");
		ingredientsBox = ingredients.getSelectedItem().toString();		
		
		//INGREDIENT SLIDERS
		for (int i = 0; i < ingredientSliders.length; i++) {
			JPanel ingAmounts = new JPanel();
			JLabel ingAmountsTitle = new JLabel("For Rolls: Choose amount of " + ingredientSliders[i]);
			ingAmounts.add(ingAmountsTitle);
			//Border border4 = BorderFactory.createTitledBorder(ingAmountsTitle);
			//ingAmounts.setBorder(border4);
			add(ingAmounts);
			//ING PORTION
			slider = new JSlider(JSlider.HORIZONTAL, 0, 15, 0);
			slider.setMajorTickSpacing(3);
			slider.setMinorTickSpacing(1);
			slider.setPaintTicks(true);
			Hashtable<Integer, JLabel> position = new Hashtable<Integer, JLabel>();
	        position.put(0, new JLabel("0"));
	        position.put(3, new JLabel(".30"));
	        position.put(6, new JLabel(".60"));
	        position.put(9, new JLabel(".90"));
	        position.put(12, new JLabel("1.20"));
	        position.put(15, new JLabel("1.50"));
	        slider.setLabelTable(position);
			slider.setPaintLabels(true);
	        ingAmounts.add(slider);
	        ingSliders[i] = slider;
	        ingredientRollPortions[i] = slider.getValue()/10 * 100/100.0;
		}
		
		//NAME ROLL
		JPanel namePanel = new JPanel();
		JLabel namePanelLabel = new JLabel("Name of Roll: ");
		add(namePanel);
		nameOfRoll = new JTextField("", 20);
		//rollName = nameOfRoll.getText();
		namePanel.add(namePanelLabel);
		namePanel.add(nameOfRoll);
		
		//PLATE POSITION
		JPanel platePosition = new JPanel();
		JLabel platePositionTitle = new JLabel("Put your plate on position: ");
		platePosition.add(platePositionTitle);
		//Border border5 = BorderFactory.createTitledBorder(platePositionTitle);
		//platePosition.setBorder(border5);
		add(platePosition);
		Integer[] positionsOnBelt = new Integer[20];
		
		for (int i = 0; i < 20; i++) {
			positionsOnBelt[i] = i;
		}		
		platePositionOps = new JComboBox(positionsOnBelt);		
		platePosition.add(platePositionOps);
		platePositionOps.addActionListener(this);
		platePositionOps.setActionCommand("plate pos");
		platePositionBox =  (int) platePositionOps.getSelectedItem();		
		
		
		
        
		//ADD PLATE
		JButton addPlate = new JButton("Add Plate!");		
		addPlate.addActionListener(this);
		addPlate.setActionCommand("add");
		add(addPlate);

	}
	
	


	public void registerChefListener(ChefViewListener cl) {
		listeners.add(cl);
	}

	private void makeRedPlateRequest(Sushi plate_sushi, int plate_position) {
		for (ChefViewListener l : listeners) {
			l.handleRedPlateRequest(plate_sushi, plate_position);
			
		}
	}

	private void makeGreenPlateRequest(Sushi plate_sushi, int plate_position) {
		for (ChefViewListener l : listeners) {
			l.handleGreenPlateRequest(plate_sushi, plate_position);
		}
	}

	private void makeBluePlateRequest(Sushi plate_sushi, int plate_position) {
		for (ChefViewListener l : listeners) {
			l.handleBluePlateRequest(plate_sushi, plate_position);
		}
	}
	
	private void makeGoldPlateRequest(Sushi plate_sushi, int plate_position, double price) {
		for (ChefViewListener l : listeners) {
			l.handleGoldPlateRequest(plate_sushi, plate_position, price);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {		
		switch (e.getActionCommand()) {
		case "color":
			colorsBox = (String) colors.getSelectedItem();
			if (colorsBox.equals("gold")) {
				goldPlatePriceSlider.setVisible(true);
			}
			break;
		case "sushi type":
			sushiBox = (String) sushi.getSelectedItem();
			break;
		case "single ing":
			ingredientsBox = (String) ingredients.getSelectedItem();		
			break;
		case "plate pos":
			platePositionBox =  (int) platePositionOps.getSelectedItem();
			System.out.println(platePositionBox);
			break;	
		case "add" :
			
		
			if (sushiBox.equals("sashimi")) {
				if (ingredientsBox.equals("eel")) {
					switch (colorsBox) {
					case "red": 
						makeRedPlateRequest(new Sashimi(SashimiType.EEL), platePositionBox);
						break;
					case "blue":
						makeBluePlateRequest(new Sashimi(SashimiType.EEL), platePositionBox);
						break;
					case "green": 
						makeGreenPlateRequest(new Sashimi(SashimiType.EEL), platePositionBox);
						break;
					case "gold": 
						makeGoldPlateRequest(new Sashimi(SashimiType.EEL), platePositionBox, goldPrice);
						break;

					}
				} 
				if (ingredientsBox.equals("yellowtail")) {
					switch (colorsBox) {
					case "red": 
						makeRedPlateRequest(new Sashimi(SashimiType.YELLOWTAIL), platePositionBox);
						break;
					case "blue":
						makeBluePlateRequest(new Sashimi(SashimiType.YELLOWTAIL), platePositionBox);
						break;
					case "green": 
						makeGreenPlateRequest(new Sashimi(SashimiType.YELLOWTAIL), platePositionBox);
						break;
					case "gold": 
						makeGoldPlateRequest(new Sashimi(SashimiType.YELLOWTAIL), platePositionBox, goldPrice);
						break;

					}
				}
				if (ingredientsBox.equals("crab")) {
					switch (colorsBox) {
					case "red": 
						makeRedPlateRequest(new Sashimi(SashimiType.CRAB), platePositionBox);
						break;
					case "blue":
						makeBluePlateRequest(new Sashimi(SashimiType.CRAB), platePositionBox);
						break;
					case "green": 
						makeGreenPlateRequest(new Sashimi(SashimiType.CRAB), platePositionBox);
						break;
					case "gold": 
						makeGoldPlateRequest(new Sashimi(SashimiType.CRAB), platePositionBox, goldPrice);
						break;

					}
				}
				if (ingredientsBox.equals("tuna")) {
					switch (colorsBox) {
					case "red": 
						makeRedPlateRequest(new Sashimi(SashimiType.TUNA), platePositionBox);
						break;
					case "blue":
						makeBluePlateRequest(new Sashimi(SashimiType.TUNA), platePositionBox);
						break;
					case "green": 
						makeGreenPlateRequest(new Sashimi(SashimiType.TUNA), platePositionBox);
						break;
					case "gold": 
						makeGoldPlateRequest(new Sashimi(SashimiType.TUNA), platePositionBox, goldPrice);
						break;

					}
				}
				if (ingredientsBox.equals("shirmp")) {
					switch (colorsBox) {
					case "red": 
						makeRedPlateRequest(new Sashimi(SashimiType.SHRIMP), platePositionBox);
						break;
					case "blue":
						makeBluePlateRequest(new Sashimi(SashimiType.SHRIMP), platePositionBox);
						break;
					case "green": 
						makeGreenPlateRequest(new Sashimi(SashimiType.SHRIMP), platePositionBox);
						break;
					case "gold": 
						makeGoldPlateRequest(new Sashimi(SashimiType.SHRIMP), platePositionBox, goldPrice);
						break;

					}
				}			
		}
		if (sushiBox.equals("nigiri")) {
			if (ingredientsBox.equals("eel")) {
				switch (colorsBox) {
				case "red": 
					makeRedPlateRequest(new Nigiri(NigiriType.EEL), platePositionBox);
					break;
				case "blue":
					makeBluePlateRequest(new Nigiri(NigiriType.EEL), platePositionBox);
					break;
				case "green": 
					makeGreenPlateRequest(new Nigiri(NigiriType.EEL), platePositionBox);
					break;
				case "gold": 
					makeGoldPlateRequest(new Nigiri(NigiriType.EEL), platePositionBox, goldPrice);
					break;
				}
			} 
			if (ingredientsBox.equals("yellowtail")) {
				switch (colorsBox) {
				case "red": 
					makeRedPlateRequest(new Nigiri(NigiriType.YELLOWTAIL), platePositionBox);
					break;
				case "blue":
					makeBluePlateRequest(new Nigiri(NigiriType.YELLOWTAIL), platePositionBox);
					break;
				case "green": 
					makeGreenPlateRequest(new Nigiri(NigiriType.YELLOWTAIL), platePositionBox);
					break;
				case "gold": 
					makeGoldPlateRequest(new Nigiri(NigiriType.YELLOWTAIL), platePositionBox, goldPrice);
					break;
				}
			}
			if (ingredientsBox.equals("crab")) {
				switch (colorsBox) {
				case "red": 
					makeRedPlateRequest(new Nigiri(NigiriType.CRAB), platePositionBox);
					break;
				case "blue":
					makeBluePlateRequest(new Nigiri(NigiriType.CRAB), platePositionBox);
					break;
				case "green": 
					makeGreenPlateRequest(new Nigiri(NigiriType.CRAB), platePositionBox);
					break;
				case "gold": 
					makeGoldPlateRequest(new Nigiri(NigiriType.CRAB), platePositionBox, goldPrice);
					break;
				}
			}
			if (ingredientsBox.equals("tuna")) {
				switch (colorsBox) {
				case "red": 
					makeRedPlateRequest(new Nigiri(NigiriType.TUNA), platePositionBox);
					break;
				case "blue":
					makeBluePlateRequest(new Nigiri(NigiriType.TUNA), platePositionBox);
					break;
				case "green": 
					makeGreenPlateRequest(new Nigiri(NigiriType.TUNA), platePositionBox);
					break;
				case "gold": 
					makeGoldPlateRequest(new Nigiri(NigiriType.TUNA), platePositionBox, goldPrice);
					break;
				}
			}
			if (ingredientsBox.equals("shrimp")) {
				switch (colorsBox) {
				case "red": 
					makeRedPlateRequest(new Nigiri(NigiriType.SHRIMP), platePositionBox);
					break;
				case "blue":
					makeBluePlateRequest(new Nigiri(NigiriType.SHRIMP), platePositionBox);
					break;
				case "green": 
					makeGreenPlateRequest(new Nigiri(NigiriType.SHRIMP), platePositionBox);
					break;
				case "gold": 
					makeGoldPlateRequest(new Nigiri(NigiriType.SHRIMP), platePositionBox, goldPrice);
				}
			}			
		}
		if (sushiBox.equals("roll")) {
			for (int i = 0; i < ingSliders.length; i++) {
				ingredientRollPortions[i] = ingSliders[i].getValue()/10.0;

			}
			ArrayList<IngredientPortion> rollAmts = new ArrayList<IngredientPortion>();
			for (int i = 0; i < ingredientRollPortions.length; i++) {
				
				if (ingredientRollPortions[i] != 0.0) {
				
					switch (ingredientSliders[i]) {
					case "Avocado": 
						rollAmts.add(new AvocadoPortion(ingredientRollPortions[i]));
						break;
					case "Eel": 
						rollAmts.add(new EelPortion(ingredientRollPortions[i]));
						break;
					case "Tuna": 
						rollAmts.add(new TunaPortion(ingredientRollPortions[i]));
						break;
					case "Shrimp":
						rollAmts.add(new ShrimpPortion(ingredientRollPortions[i]));
						break;
					case "Yellowtail":
						rollAmts.add(new YellowtailPortion(ingredientRollPortions[i]));
						break;
					case "Crab":
						rollAmts.add(new CrabPortion(ingredientRollPortions[i]));
						break;
					case "Seaweed":
						rollAmts.add(new SeaweedPortion(ingredientRollPortions[i]));
						break;
					case "Rice":
						rollAmts.add(new RicePortion(ingredientRollPortions[i]));
						break;
					}					
				}
			}
			IngredientPortion[] rollPortionsArray = rollAmts.toArray(new IngredientPortion[rollAmts.size()]);
			switch (colorsBox) {
			case "red": 
				makeRedPlateRequest(new Roll(nameOfRoll.getText(), rollPortionsArray), platePositionBox);
				break;
			case "blue":
				makeBluePlateRequest(new Roll(nameOfRoll.getText(), rollPortionsArray), platePositionBox);
				break;
			case "green": 
				makeGreenPlateRequest(new Roll(nameOfRoll.getText(), rollPortionsArray), platePositionBox);
				break;
			case "gold": 
				makeGoldPlateRequest(new Roll(nameOfRoll.getText(), rollPortionsArray), platePositionBox, goldPrice);
				break;
			}
			
		}
		
		for (int i = 0; i < ingredientRollPortions.length; i++) {
			ingSliders[i].setValue(0);
		}
		colors.setSelectedItem("");
		sushi.setSelectedItem("");
		platePositionOps.setSelectedItem(0);
		goldPlatePriceSlider.setVisible(false);
		ingredients.setSelectedItem("");
		nameOfRoll.setText("");
		break;
			
}	
	
}
	
}
