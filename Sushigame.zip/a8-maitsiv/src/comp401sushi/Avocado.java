package comp401sushi;

public class Avocado extends IngredientImpl {
	public Avocado() {
		super("avocado", 0.22, 45, true, false, false);
	}
}
