package comp401sushi;

public class Rice extends IngredientImpl {

	public Rice() {
		super("rice", 0.12, 37, true, true, false);
	}
}
