package comp401sushi;

public class Yellowtail extends IngredientImpl {

	public Yellowtail() {
		super("yellowtail", 0.74, 57, false, false, false);
	}
}
